import { connect } from "react-redux";

import React, { Component } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  ImageBackground,
  TextInput,
  Image,
  TouchableHighlight,TouchableOpacity
} from 'react-native';

import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import bgImage from '../assets/app_back_img.png';
//import ip_tick from '../assets/.png';
 //import img from '../assets/male_not.png';
// import img1 from '../assets/female.png';
 import selectmale from '../assets/male_selected.png';
// import selectfemale from '../assets/female_selected.png';
import LinearGradient from 'react-native-linear-gradient';


//import MapView from 'react-native-maps'
class Verification extends React.Component {
    constructor(props) {
        super(props);
      //  initState = 
         this.state = {
            whichselected:'No',
       
        };
         //  this.handlerButtonOnClick = this.handlerButtonOnClick.bind(this);
    
      }
      
      handlerButtonOnClick(tmp1){
       
        this.setState({
           whichselected: tmp1
        });
      }
      showAlert = () =>
      {
      
        this.props.navigation.navigate('LinkedLoginContainer');
      }
        render(){
       
        return (
    
          <ImageBackground source={bgImage} style={styles.backgroundContainer}>
              <ScrollView style={{width:"100%"}}> 
              
           <LinearGradient 
       start={{ x: 0.1, y: 0.1 }} end={{ x: 0.5, y: 0.5 }}
       
       colors={['#dcc642', '#896100', '#f2eb80']} style={styles.linearGradient}>
         
  <Text style={{fontFamily:'Roboto',paddingTop:10,
          fontSize: 17}}>
            
Profile </Text>
</LinearGradient>

<LinearGradient 
       start={{ x: 0.1, y: 0.1 }} end={{ x: 0.5, y: 0.5 }}
       
       colors={['#dcc642', '#896100', '#f2eb80']} style={{marginTop:200,marginLeft:'5%',width:'90%',paddingLeft:10,borderRadius:10}}>
         
  <Text style={{fontFamily:'Roboto',paddingTop:10,height:200,
          fontSize: 17}}>
            
            Your Account has beed successfully submitted. You will receive an confirmation email within 48 hrs. </Text>
</LinearGradient>


</ScrollView>
            </ImageBackground>
        
      );
    };
    }
    
    const styles = StyleSheet.create({
      
      backgroundContainer: {
        flex: 1,
      
        justifyContent: 'center',
        alignItems: 'center',
      },
      baseText: {
        color:'#ded776',
        marginTop:'5%',
 paddingLeft:"10%",
       
          fontSize: 18,
        fontFamily: 'Roboto',
        textAlign:"left",
        
      },
      titleText: {
        //marginTop:20,
        color:'#ded776',
        //color:"white",
        fontSize: 18,
        fontFamily: 'Roboto',
      },
      underline:{
       
       height:2,
       marginLeft:10,
       marginRight:10,
       //paddingLeft:300,
       
    
     },
      underlineview:{
       
       height:2,
       marginLeft:30,
       marginRight:10,
       marginTop:10,
       backgroundColor:'#ded776',
       
    
     },

     underlineview1:{
       
      height:2,
      marginLeft:20,
      marginRight:10,
      marginTop:30,
      backgroundColor:'white',
      
   
    },
     container: {
            flex: 1,
            height:200,
            marginTop:'12%',
            paddingLeft:"17%",
            
             justifyContent: 'flex-start',
            
            flexDirection: 'row',
            
            
        },
        MaleText:{
          color:'#ded776',
          height:20,
          marginTop:'50%',
          //paddingLeft:"-5%",
         // paddingRight:"-10%"
        },
        
      buttonText:{
    
        
          
    
    
      },
      underline1:{
        height:5,
       marginLeft:20,
       marginRight:20,
       marginTop:20
      
      },
      linearGradient1:{
        flex:1,
        width:"90%",
         height: 35,
         marginLeft:'5%',
        
        borderRadius: 50,
        marginBottom:3,
        marginTop: 25
      },
      buttonText1:{
        textAlign:'center',
          marginTop:'2%',
          fontFamily:'Roboto',
          fontSize: 17,
      },
      alreadyText:{
        marginTop:'18%',
    color:"white",
      fontSize: 30,
    fontFamily: 'Roboto',
    textAlign:"center",
    
    
      },
      whenText:{
        color:"white",
          fontSize: 13,
        fontFamily: 'Roboto',
        marginTop:8,
        textAlign:"center"
      },
      withText:{
        color:"white",
          fontSize: 13,
        fontFamily: 'Roboto',
        marginTop:5,
        textAlign:"center"
      },
      imagepress:{
        alignItems: 'center',
        backgroundColor: '#dcc642',
        padding: 5
      },
      linearGradient:{

     
             height: 50,
            paddingLeft: 80,
            paddingRight: 80,
           
          }
    
    
    
    
    });
    
    


const mapStateToProps = state => ({
  loading: state.auth.loading,
  isAuthorised: state.auth.isAuthorised,
  eid: state.auth.eid,
  auth: state.auth,
  uid: state.auth.uid
});

const mapDispatchToProps = dispatch => ({
  fbLogin: payload => dispatch(AuthActions.fbLogin(payload)),
  requestLogin: () => dispatch(AuthActions.requestLogin()),
  showStatusBar: (type, title, message) =>
    dispatch(StatusBarActions.showStatusBar(type, title, message))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Verification);
