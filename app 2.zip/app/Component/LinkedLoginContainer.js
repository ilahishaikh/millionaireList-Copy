import { connect } from "react-redux";

import React, { Component } from 'react';
import { Pages} from 'react-native-pages';
import MapView from 'react-native-maps';


import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  Button,
  TextInput,
  StatusBar,
  TouchableOpacity,
  ImageBackground,
  Image,
  
  
  
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import img from '../assets/img.png';
import annual_income from '../assets/annual_income.png';
import poof_id_with_customer1 from '../assets/poof_id_with_customer1.png';

import calender from '../assets/calender.png';
import RBSheet from "react-native-raw-bottom-sheet";

import YourOwnComponent from './YourOwnComponent'
import { LinearTextGradient } from "react-native-text-gradient";

 
class LinkedLoginContainer extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
         
          //titleText: "Enjoy all the " ,
          
          //bodyText: 'premium features',
        };
      }
      showAlert = () =>
      {
        this.RBSheet.close()
       this.props.navigation.navigate('Verification');
      }
      render() {
        var markers = [{
          latitude: 42.882004, 
          longitude: 74.582748
          
    
        }];
        
    
      return (
       
    
        
        <Pages  indicatorPosition={'top'} indicatorColor='#ded776'
        indicatorOpacity={0.3} Style = {{backgroundColo:'Black'}}
       
        >
          <View style={styles.container}>
          <View style={{width:'100%',height:'99%'}}>
          <Text style={styles.TextStyle} >Add Your Profile Info </Text> 

          <View style={{backgroundColor:'#ded776',height:2,width:'90%',marginTop:5,marginLeft:'5%'}}></View>     
         


          <ScrollView  style={{ width: '100%',marginTop:40 }}  >
          <TextInput style={styles.tntxtstyle}  placeholder="When's your birthday?"
            placeholderTextColor = "white"/> 
             <TextInput style={styles.tntxtstyle1}  placeholder="Select Date" 
                 placeholderTextColor = "#ded776" 
    
    
                 /> 

<TouchableOpacity activeOpacity={0.8} style={styles.touachableButton} >
              
              
              <Image style={{height:20, marginTop:105,width:'45%',backgroundColor:'#ded776'}}
                      
source={calender}
/> 
</TouchableOpacity> 


                  <TextInput style={styles.tntxtstyle}  placeholder="Whats's your location?" 
                 placeholderTextColor = "white"
                 
                 /> 
                  <View style={styles.container1}>
                 <TouchableOpacity
                  style={styles.buttonContainer}
                   activeOpacity = { .5 }
                   onPress={ this.ButtonClickCheckFunction }
                  >
                 <Text style={styles.TextStylechadd}> Choose address </Text>
                 </TouchableOpacity>
              
    
                
                 <TouchableOpacity
                  style={styles.buttonContainer}
                   activeOpacity = { .5 }
                   onPress={ this.ButtonClickCheckFunction }
                  >
                 <Text style={styles.TextStylechadd}> Current Location </Text>
                 </TouchableOpacity>
                  </View>
                  <View style={styles.mapviewstyle}>
        <MapView scrollEnabled={false}
            style={styles.map}
            region={{ // initial region set to Bileto
                latitude: 50.0517273,
                longitude: 14.4286503,
                latitudeDelta: 0.0922,
                longitudeDelta: 0.0421
            }}/ >
        
    </View>

                  <TextInput style={styles.txtyourincome1}  
                 placeholderTextColor = "#ded776"
                 /> 
                  <TextInput style={styles.txtyourincome}  placeholder="What's your income?" 
                 placeholderTextColor = "white"
                 
                 /> 
                 <TextInput style={styles.tntxtstyle3}  placeholder="Select income" 
                 placeholderTextColor = "#ded776" 
                 
                 /> 
       
                     </ScrollView>
            </View>

  {/* //page 1 code */}


          
               </View>

               <View style={styles.container}>

<View style={{width:'100%',height:'99%'}}>
<Text style={styles.TextStyle} >Add Your Profile Info </Text> 

<View style={{backgroundColor:'#ded776',height:2,width:'90%',marginTop:5,marginLeft:'5%'}}></View>     



<ScrollView  style={{ width: '100%',marginTop:40 }}  >
<Text style={styles.Textavtar}> Upload your AVTAR!</Text>
            <TextInput style={styles.tntxtstyle}  placeholder="Please upload your real poteait only"
            placeholderTextColor = "white" 
             /> 
             <Image source={img} style={styles.Image1} />
            <LinearGradient 
           start={{ x: 0.5, y: 0.5 }} end={{ x: 0.10, y: 0.5 }}
           
           colors={['#dcc642', '#896100', '#f2eb80']} style={styles.linearGradient1}>
    <Text style={styles.buttonText1}>
      Add more pics
      </Text>
    </LinearGradient>
    <View style={styles.main}>
            <View style={{flexDirection:'row', marginTop:-60, justifyContent:"space-between"}}>
              <Image
                style={{width: 100, height: 100, }}
                source={img} />
              <Image
                style={{width: 100, height: 100}}
                source={img} />
                <Image
                style={{width: 100, height: 100}}
                source={img} />
            </View>
            <View style={{flexDirection:'row', marginTop:10, justifyContent:"space-between"}}>
              <Image
                style={{width: 100, height: 100}}
                source={img} />
              <Image 
              style={{width: 100, height: 100}}
              source={img} />
              <Image
                style={{width: 100, height: 100}}
                source={img} />
            </View>
            <Text>
            {/* <Text>{ this.addPadding() }</Text> */}
              <Text>
                 <Text style={{fontWeight: "bold"}}></Text>{"\n"}
              </Text>      
            </Text>
          </View>
</ScrollView>
</View>

</View>

         <View style={styles.container}>
          <View style={{width:'100%',height:'99%'}}>
          <Text style={styles.TextStyle} >Add Your Profile Info </Text> 

          <View style={{backgroundColor:'#ded776',height:2,width:'90%',marginTop:5,marginLeft:'5%'}}></View>     
         
          <ScrollView  style={{ width: '100%',marginTop:40 }}  >
          <Text style={styles.TexttellusStyle}> TELL US ABOUT YOURSELF </Text>
          <TouchableOpacity
              style={styles.describebtnStyle}
              activeOpacity = { .5 }
              onPress={ this.ButtonClickCheckFunction }
           >
               
                <Text style={styles.TxtpotrtStyle}> How can you describe yourself? </Text>
    </TouchableOpacity>
    <View style={{backgroundColor:'#ded776',height:2,width:'90%',marginTop:20,marginLeft:'5%'}}></View>     
    <Text style={styles.occupationtext}> Occupation </Text>
          <TouchableOpacity
              style={styles.uploadpotrtbtnStyle}
              activeOpacity = { .5 }
              onPress={ this.ButtonClickCheckFunction }
           >
               
                <Text style={styles.TxtpotrtStyle}> Please enter your Occupation  </Text>
                
    </TouchableOpacity>
    <LinearGradient 
           start={{ x: 0.5, y: 0.5 }} end={{ x: 0.10, y: 0.5 }}
           
           colors={['#dcc642', '#896100', '#f2eb80']} style={styles.linearGradient}>
    <Text style={styles.buttonText}>
      Next
      </Text>
    </LinearGradient>
            </ScrollView>

          </View>

          </View>




         
          <View style={styles.container}>


       
<View style={{width:'100%',height:'99%'}}>
<Text style={styles.TextStyle} >Add Your Profile Info </Text> 

<View style={{backgroundColor:'#ded776',height:2,width:'90%',marginTop:5,marginLeft:'5%'}}></View>     


<View style={{padding:20}}>
<ScrollView  style={{ width: '100%',marginTop:40 }}  >
<Text style={{color:'white',position:'absolute',marginTop:9 ,padding:10}}>1 -  Upload your valid government id which is true and clear</Text>

<ImageBackground source={poof_id_with_customer1} style={{height:200,opacity:.3}}>
</ImageBackground>
<TouchableOpacity
          style={styles.uploadpotrtbtnStyle4}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
           
            <Text style={styles.TxtpotrtStyle}> Upload  </Text>
            
</TouchableOpacity>
<ImageBackground  source={annual_income} style={{height:200,marginTop:20,opacity:.3}}>
  
</ImageBackground>


<Text style={{color:'white',position:'absolute',marginTop:255,padding:10 }}>2 -  Take a photo of you holding id you upload in the previous step make sure your face and info on photoid is visible</Text>



<TouchableOpacity
          style={styles.uploadpotrtbtnStyle4}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
           
            <Text style={styles.TxtpotrtStyle}> Upload  </Text>
            
</TouchableOpacity>

<Text style={{color:'white',position:'absolute',marginTop:520,padding:10 }}>3 -  Upload a document to show your annual income or net assets which includes your full name</Text>

<ImageBackground source={poof_id_with_customer1} style={{height:200,marginTop:20,opacity:.3}}>
</ImageBackground>
<TouchableOpacity
          style={styles.uploadpotrtbtnStyle4}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
           
            <Text style={styles.TxtpotrtStyle}> Upload  </Text>
            
</TouchableOpacity>

<TouchableOpacity
          style={styles.verifybtnStyle}
          activeOpacity = { .5 }
          onPress={() => {
            this.RBSheet.open();
          }}
       >
           
            <Text style={styles.TxtverifyStyle}> Verify  </Text>
            
</TouchableOpacity>
<RBSheet
          ref={ref => {
            this.RBSheet = ref;
          }}
          height={350}
          duration={250}
          customStyles={{
            container: {
              justifyContent: "center",
              alignItems: "center",
              borderTopRightRadius:30,
              borderTopLeftRadius:30

            }
          }}
        >
          <YourOwnComponent onChange={this.showAlert} />
        </RBSheet>
     

</ScrollView>
</View>
</View>
</View>


            
          </Pages>
          
              
      );
      }
      addPadding() {
        const padding = Array.apply(null, Array(16)).map(() => '').join('');
        return Array.apply(null, Array(8)).map(() => padding + '\n');
      }
    
    
    }
    const styles = StyleSheet.create({
        container: {
         
            flex: 1,
       
           backgroundColor:'black',
         
           flexDirection: "row",
            paddingTop: StatusBar.currentHeight,
            
        },
        TextStyle:{
          color:'#ded776',
          fontSize:20,
          width:'90%',
          marginLeft:'5%'
         
         
          
        },
        tntxtstyle3:{
       
          paddingLeft: 20,
          color:'white',
          //backgroundColor:'#323232',
          width:'90%',
          marginLeft:'5%',
          //marginRight:'10%',
          marginTop:20,
          borderRadius:50,
          borderWidth:1,
          borderColor:'#ded776'
          //marginBottom:"20%"
    
          //textAlign: 'center',
         
        },
      tntxtstyle:{
       
          paddingLeft: 20,
          color:'white',
          backgroundColor:'#323232',
          width:'90%',
          marginLeft:'5%',
          //marginRight:'10%',
          marginTop:20,
          borderRadius:50,
          borderWidth:1,
          //borderColor:'#ded776'
          //marginBottom:"20%"
    
          //textAlign: 'center',
         
        },
        
        linearGradient:{
          flex:1,
          width:'30%',
          height: 40, 
          //marginTop: 70, 
          //height:35,
         marginLeft:'35%',
         //marginRight:'60%',
         marginTop:80,
         marginBottom:80,
         borderRadius:50
         /*
         height: 50,
        paddingLeft: 80,
        paddingRight: 80,
        //borderRadius: 50,
        marginBottom:3,
        marginTop: "-2%"*/
    
         
        },
        linearGradient2:{
          flex:1,
          width:'30%',
          height: 40, 
          //marginTop: 70, 
          //height:35,
         marginLeft:'35%',
         //marginRight:'60%',
         //marginTop:50,
         //marginBottom:50,
         borderRadius:50
        },
        buttonText2:{
          textAlign:'center',
          //marginLeft:'40%',
          marginTop:'10%'
        },
        buttonText:{
          textAlign:'center',
          //marginLeft:'40%',
          marginTop:'10%'
          
        },
        Textavtar:{
          flex:1,
          fontSize:15,
          color:'#ded776',
          textAlign:'center',
          //width:'50%',
          //marginLeft:'30%',
          //marginRight:'30%',
          marginTop:10,
        },
        Image1:{
          flex:1,
          width: 170, 
          height: 170,
          //width:'58%',
          marginTop:15,
          
          //alignItems: 'center',
          marginLeft:'25%',
          marginRight:'25%',
        },
        linearGradient1:{
          width:'40%',
          
          height:30,
         marginLeft:'30%',
         //marginRight:'90%',
         marginTop:10,
         marginBottom:40,
         borderRadius:50
        },
        buttonText1:{
          textAlign:'center',
          //marginLeft:'25%',
          marginTop:'2%'
        },
        tntxtstyle1:{
          paddingLeft: 20,
          borderWidth: 1,
          borderColor: '#ded776',
          width:'90%',
          marginLeft:'5%',
          //marginRight:'10%',
          marginTop:20,
          borderRadius:50,
    
        },
        underline:{
          
          
          marginRight:20
        },
            container1: {
            flex: 1,
           
            width:"100%",
            paddingLeft:"2%",
            paddingRight:"2%",
    
             //justifyContent: 'center',
            flexDirection: 'row',
            //alignItems: 'center',
            
        },
        buttonContainer: {
            flex: 1,
            height:40,
            width:"90%",
          
           
            paddingTop:10,
            paddingBottom:10,
            marginLeft:10,
            marginRight:10,
          
            borderRadius:50,
            borderColor: '#ded776',
            borderWidth: 1,
            //flexDirection: 'row',
            paddingLeft:"4%",
            paddingRight:"4%",
            marginTop:20,
            //marginLeft:"10%",
            //marginRight:"10%"
            
    
        },
        mapstyl:{
          //flex:1,
          height:350,
          width:300,
          marginLeft:"5%",
          //marginRight:"30%",
          marginTop:"-15%",
          paddingRight:30,
          resizeMode: 'contain',
          left: 20,
           right:-20 
      //top: 50, 
      //width: 20,
      // height: 40}
         // width:300
         
        },
        TxtpotrtStyle:{
        color:'#fff',
        textAlign:'left',
        paddingLeft:'5%'
      },
      TexttellusStyle:{
        flex: 1,
        fontSize: 20,
        marginTop:20,
        marginBottom:10,
        fontFamily: 'Gill Sans',
        backgroundColor:'black',
        color:'#ded776',
        textAlign:'center',
      },
    describebtnStyle:{
      height:90,
        flex:1,
        marginTop:30,
        //marginBottom:10,
        paddingTop:10,
        
        //paddingBottom:30,
        marginLeft:30,
        marginRight:30,
        backgroundColor:'#323232',
        borderRadius:25,
        borderWidth: 1,
        borderColor: '#808080'
      },
      TextStyle4:{
        flex: 1,
     backgroundColor:'black',
     
     color:'#ded776',
    //textAlign: 'left',
    fontSize: 22,
    
    //marginTop:10,
    
    flexDirection: 'row',
    
    textDecorationStyle: "solid",
    //textDecorationColor: "#ded776"
    //lineHeight: 30
    
      },
      baseText4:{
        fontFamily: 'Cochin',
        borderBottomColor:'#ded776',
        borderWidth:2,
      },
      occupationtext:{
        marginTop:10,
        marginBottom:20,
        fontSize:18,
        fontFamily: 'Cochin',
        textAlign:'center',
        color:'#ded776',
        //backgroundColor:'black'
    
      },
      linearGradient4:{
        flex: 1,
        marginTop:70,
        marginBottom:-70,
        paddingLeft: 10,
        paddingRight: 10,
        marginLeft:110,
        marginRight:110,
        borderRadius: 50,
        //borderBottomWidth:-100,
        borderTopWidth:50
      },
    
    buttonText4:{
        fontSize: 18,
        fontFamily: 'Gill Sans',
        textAlign: 'center',
        margin:25,
     
        color: 'black',
        backgroundColor: 'transparent',
    },
    MainContainer3:{
      justifyContent: 'center',
      flex:1,
     //borderBottomColor: '#ded776',
     //marginBottom:50,
      //borderTopWidth:50,
      //borderBottomWidth: 100,
      
       backgroundColor:'black'
      }, 
      uploadpotrtbtnStyle:{
        //flex:1,
        marginTop:2,
        paddingTop:10,
        paddingBottom:10,
        marginLeft:30,
        marginRight:30,
        backgroundColor:'#323232',
        borderRadius:50,
        borderWidth: 2,
        borderColor: '#808080'
      },
      main: {
        flex: 1,
        margin: 30,
        resizeMode:'contain',
        //borderRadius: 40,
        //borderColor:'#ded776'
      },
    
      image: {
        //width: 600,
        //height: 110,
        position: 'absolute',
      },
      TextStylechadd:{
        textAlign:'center',
        fontSize:12,
        marginTop:1,
        color:'#ded776'
      },
      txtyourincome:{
        // marginTop:20,
        // paddingLeft: 20,
        //   borderWidth: 1,
        //   borderColor: '#ded776',
        //   width:'90%',
        //   marginLeft:'5%',
        //   //marginRight:'10%',
        //   //marginTop:10,
        //   borderRadius:50,

          paddingLeft: 20,
          color:'white',
          backgroundColor:'#323232',
          width:'90%',
          marginLeft:'5%',
          //marginRight:'10%',
          marginTop:20,
          borderRadius:50,
          borderWidth:1
    
      },
      mapviewstyle:{
        
        top:0,
        left:0,
        bottom:0,
        marginTop:20,
        marginBottom:10,
        right:0,
        justifyContent:'flex-end',
        alignItems:'center',
        
      },
      map:{
        height:200,
        width:"90%",
       
        marginLeft:20,
        marginRight:20,
        flex:1,
       
        top:0,
        left:0,
        bottom:0,
        right:0
      },
      txtyourincome1:{
       
      
          borderWidth: 1,
          borderColor: '#ded776',
          width:'90%',
          marginLeft:'5%',
          //marginRight:'10%',
          marginTop:20,
          borderRadius:50,
      },
      txtvalidid:{
        flex:1,
        //position:'absolute',
        marginTop:-10,
        padding: 2,
    
        //marginTop:20,
        color:'white',
        fontSize:12
      },
      uploadpotrtbtnStyle4:{
        alignItems:'center',
        marginTop:-10,
        paddingTop:10,
        paddingBottom:10,
        margin:1,
        backgroundColor:'#696969',
        borderRadius:8,
        borderWidth: 2,
        borderColor: '#696969'
      },
      captures1:{
        flexWrap: "wrap",
        height:200,
        width:'90%',
        marginLeft:'5%',
        
      },
      verifybtnStyle:{
        height:40,
        width:"40%",
        alignItems:'center',
        marginTop:10,
        //paddingTop:10,
        //paddingBottom:10,
        marginLeft:"30%",
        marginRight:"30%",
        //marginRight:90,
        backgroundColor:'#696969',
        borderRadius:12,
        borderWidth: 2,
        borderColor: '#696969'
      },
      txtvalidid2:{
        flex:1,
        flexDirection:'row',
        marginTop:20,
        color:'white',
        fontSize:12
      },touachableButton: {
        position: 'absolute',
        right: 3,
        height: 40,
        width: 55,
        padding: 2
      },
      TxtverifyStyle:{
        marginTop:8,
        textAlign:'center',
        color:'white',
      }
    });





const mapStateToProps = state => ({
  loading: state.auth.loading,
  isAuthorised: state.auth.isAuthorised,
  eid: state.auth.eid,
  auth: state.auth,
  uid: state.auth.uid
});

const mapDispatchToProps = dispatch => ({
  fbLogin: payload => dispatch(AuthActions.fbLogin(payload)),
  requestLogin: () => dispatch(AuthActions.requestLogin()),
  showStatusBar: (type, title, message) =>
    dispatch(StatusBarActions.showStatusBar(type, title, message))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(LinkedLoginContainer);
