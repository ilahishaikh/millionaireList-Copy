import { asyncActionType } from "../../util";

export const SET_NOTIFICATION = asyncActionType("SET_NOTIFICATION");
