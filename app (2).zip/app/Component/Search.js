/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  TouchableOpacity,
  Image,Switch,Button,TextInput
  
} from 'react-native';

import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import ic_tick from '../assets/ic_tick.png'
import CardStack, { Card } from 'react-native-card-stack-swiper';
import rotating from '../assets/rotating.png'
import ic_message from '../assets/ic_message.png'
import user_profile from '../assets/user_profile.png'
import LinearGradient from 'react-native-linear-gradient';
import searchgolden from '../assets/searchgolden.png'
import directional from '../assets/directional.png'
import mars from '../assets/mars.png'
import sound from '../assets/sound.png'
import lovely from '../assets/lovely.png'
import coffee from '../assets/coffee.png'
import body from '../assets/body.png'
import place from '../assets/place.png'
import glass from '../assets/glass.png'
import ic_camera from '../assets/ic_camera.png'
import ic_linked_in from '../assets/ic_linked_in.png'
import education from '../assets/education.png'
import ic_up_quotes from '../assets/education.png'
import RBSheet from "react-native-raw-bottom-sheet";

import BottomSheet from 'reanimated-bottom-sheet'
import msg from '../assets/msg.png'
import flash from '../assets/flash.png'
import ic_reswipe from '../assets/ic_reswipe.png'


export default class App extends React.Component{

    renderInner = () => (
        <View style={styles.panel}>
          
    <View style={{flex:1,justifyContent:'center'}}>
      <LinearGradient
           start={{ x: 0.1, y: 0.1 }} end={{ x: 0.5, y: 0.5 }}
           
           colors={['#dcc642', '#896100', '#f2eb80']}  >
    
          
           
               
    <View style={{justifyContent:'center', padding:15}}>
    
              <Text style={styles.fontstyle}>Sexual Preferences </Text>  
    
       
    
        <View style={{justifyContent:'center', flexDirection:'row'}}>
         <LinearGradient style={{flexDirection:'row',width:'100%',justifyContent:'center',height:30,borderRadius:50}}
           
           colors={['#dcc642', '#896100', '#f2eb80']}  >
               <Text>Straight   </Text>
               <Text>Gray   </Text>  
                  <Text>Bisexual</Text> 
        </LinearGradient>
    
        </View>
    
    
    
    <View style={{flexDirection:'row'}}>
      <Text style={styles.fontstyle}>Show People within </Text> 
        <Text style={{color:'white',marginTop:3,left:8}}>79 km </Text> 
    
    
       </View>
    
        <View style={{justifyContent:'center', flexDirection:'row', padding:15}}>
         <LinearGradient style={{flexDirection:'row',width:'80%',justifyContent:'center',height:10,borderRadius:50}}
           
           colors={['#dcc642', '#896100', '#f2eb80']}  >
               
        </LinearGradient>
    
        </View>
    
    
    
    
    
        
      <View style={{flexDirection:'row'}}>
      <Text style={styles.fontstyle}>Age limit</Text> 
        <Text style={{color:'white',marginTop:3,left:8}}>28 years </Text> 
    
    
       </View>
    
        <View style={{justifyContent:'center', flexDirection:'row', padding:15}}>
         <LinearGradient style={{flexDirection:'row',width:'80%',justifyContent:'center',height:10,borderRadius:50}}
           
           colors={['#dcc642', '#896100', '#f2eb80']}  >
               
        </LinearGradient>
    
        </View>
    
    
    
        <View style={{flexDirection:'row'}}>
      <Text style={styles.fontstyle}>Show my age</Text> 
                          <Switch style={{left:180}}
                        onValueChange ={(switchValue)=>this.setState({switchValue})}/> 
    
       </View>
    
    
    
    
    
    
    
    <View style={{flexDirection:'row',marginTop:10}}>
      <Text style={styles.fontstyle}>Contact Preferences</Text> 
    
    
       </View>
    
        <View style={{flexDirection:'row',marginTop:10}}>
      <Text style={{color:'white'}}>enable email notification</Text> 
                          <Switch style={{left:135}}
                        onValueChange ={(switchValue)=>this.setState({switchValue})}/> 
    
       </View>
    
    
    
     
    
    
    
    <View style={{flexDirection:'row',marginTop:10}}>
      <Text style={{color:'white'}}> Recive monthly Newsletter</Text> 
                          <Switch style={{left:120}}
                        onValueChange ={(switchValue)=>this.setState({switchValue})}/> 
    
       </View>   
    
    
    
    
    
    
    <View style={{flexDirection:'row',marginTop:10}}>
      <Text style={styles.fontstyle}>About</Text> 
    
    
       </View>
    
        <View style={{marginTop:10}}>
      <Text style={{color:'white'}}>Term of use</Text> 
                          
      <Text style={{color:'white',marginTop:10}}>Privacy policy</Text> 
        <Text style={{color:'white',marginTop:10}}> Get support</Text> 
    
    
       </View>
    
    
    
    
    
       <View style={{flexDirection:'row',marginTop:10}}>
      <Text style={styles.fontstyle}>Acount</Text> 
    
    
       </View>
    
        <View style={{marginTop:10}}>
      <Text style={{color:'white'}}>Change Email Address</Text> 
                          
      <Text style={{color:'white',marginTop:10}}>Change Password</Text> 
        <Text style={{color:'white',marginTop:10}}> Logout</Text> 
    
    
       </View>
    
    </View>
    
    
    
    
    
    
    
    
    
     </LinearGradient>
      
     </View>
    
         
        </View>
      )
    
      renderHeader = () => (
        <View style={styles.header}>

      
        <View style={styles.panelHeader}>
            
            <View style={styles.panelHandle} />
    
    
                  </View> 
        </View>
      )
    
  render(){
   
    return (

<View style={{ flex: 1 }}>


  
{/*search*********************************************************** */}

<View style={{flex:7,justifyContent:'center'}}>


       <ScrollView>
       
           
<View style={{justifyContent:'center', padding:10}}>

          <Text style={{fontSize:20}}>Occupation </Text>  

   

    <View style={{justifyContent:'center', flexDirection:'row',marginTop:15}}>
 <ScrollView horizontal={true} showsHorizontalScrollIndicator={false} >
      <TouchableOpacity 
          style={styles.btnstyle}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
       
           

           <Text>Finance   </Text>


            
  </TouchableOpacity>
       
        

     <TouchableOpacity 
          style={styles.btnstyle}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
 
           <Text>Banking   </Text>
            
  </TouchableOpacity>



     <TouchableOpacity 
          style={styles.btnstyle}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
 
           <Text>Startups   </Text>
            
  </TouchableOpacity>

  <TouchableOpacity 
          style={styles.btnstyle}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
 
           <Text>Invester   </Text>
            
  </TouchableOpacity>


     <TouchableOpacity 
          style={styles.btnstyle}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
 
           <Text>Fintech   </Text>
            
  </TouchableOpacity>    
 </ScrollView>
    </View>





</View>



           
<View style={{justifyContent:'center', padding:15}}> 

          <Text style={{fontSize:20}}>Languages </Text>  

   

    <View style={{justifyContent:'center', flexDirection:'row',marginTop:15}}>
 <ScrollView horizontal={true} showsHorizontalScrollIndicator={false} 
>
      <TouchableOpacity 
          style={styles.btnstyle}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
       
           

           <Text>English   </Text>


            
  </TouchableOpacity>
       
        

     <TouchableOpacity 
          style={styles.btnstyle}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
 
           <Text>Hindi   </Text>
            
  </TouchableOpacity>



     <TouchableOpacity 
          style={styles.btnstyle}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
 
           <Text>German   </Text>
            
  </TouchableOpacity>

  <TouchableOpacity 
          style={styles.btnstyle}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
 
           <Text>French   </Text>
            
  </TouchableOpacity>


      
 </ScrollView>
    </View>




</View>






           
<View style={{justifyContent:'center', padding:15}}> 

          <Text style={{fontSize:20}}>Looking for </Text>  

   
 
    <View style={{justifyContent:'center', flexDirection:'row',marginBottom:15,marginTop:15}}>

      <TouchableOpacity 
          style={styles.btnstyle}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
       
           

           <Text>Dating   </Text>


            
  </TouchableOpacity>
       
        

     <TouchableOpacity 
          style={{width:100,borderWidth:1,height:30,justifyContent:'center',alignItems:'center',borderRadius:50,marginRight:8}}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
 
           <Text>Relationship   </Text>
            
  </TouchableOpacity>



     <TouchableOpacity 
          style={styles.btnstyle}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
 
           <Text>Hookup   </Text>
            
  </TouchableOpacity>

     
    </View>




</View>



    
<View style={{ padding:15,flexDirection:'row'}}> 

  <Text style={{fontSize:20}} >Profile match 80%</Text> 
   {/* <Text style={{left:8}}>28 years </Text> */} 


   </View>

    <View style={{justifyContent:'center', flexDirection:'row', padding:15}}>
     <LinearGradient style={{flexDirection:'row',width:'90%',justifyContent:'center',height:20,borderRadius:50}}
       
       colors={['#dcc642', '#896100', '#f2eb80']}  >
           
    </LinearGradient>

    </View>



<View style={{ padding:15,flexDirection:'row'}}> 

  <Text style={{fontSize:20}} >People show within 80 km</Text> 
   {/* <Text style={{left:8}}>28 years </Text> */} 


   </View>

    <View style={{justifyContent:'center', flexDirection:'row', padding:15}}>
     <LinearGradient style={{flexDirection:'row',width:'90%',justifyContent:'center',height:20,borderRadius:50}}
       
       colors={['#dcc642', '#896100', '#f2eb80']}  >
           
    </LinearGradient>

    </View>








           
<View style={{justifyContent:'center', padding:15}}> 

          <Text style={{fontSize:20}}>Drink or Smoke </Text>  

   

    <View style={{justifyContent:'center', flexDirection:'row',marginTop:15}}>

      <TouchableOpacity 
          style={styles.btnstyle}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
       
           

           <Text> No  </Text>


            
  </TouchableOpacity>
       
        

   <TouchableOpacity 
          style={{width:100,borderWidth:1,height:30,justifyContent:'center',alignItems:'center',borderRadius:50,marginRight:8}}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
 
           <Text>Chain Smoker   </Text>
            
  </TouchableOpacity>



     <TouchableOpacity 
          style={{width:100,borderWidth:1,height:30,justifyContent:'center',alignItems:'center',borderRadius:50,marginRight:8}}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
 
           <Text>Ocassionally   </Text>
            
  </TouchableOpacity>

 


      
    </View>




</View>


<View style={{ padding:15,flexDirection:'row'}}> 

  <Text style={{fontSize:20}} >Location</Text> 
   {/* <Text style={{left:8}}>28 years </Text> */} 


   </View>

    <View style={{justifyContent:'center', flexDirection:'row', padding:15}}>
    

    <TextInput style={{width:'100%',borderWidth:1,borderRadius:50}}> </TextInput>

    </View>




 <View style={{justifyContent:'center', padding:15}}> 


   

    <View style={{justifyContent:'center', flexDirection:'row',marginTop:15}}>
 <ScrollView horizontal={true} showsHorizontalScrollIndicator={false} 
>
      <TouchableOpacity 
          style={styles.btnstyle1}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
       
           

           <Text>New York Area   </Text>


            
  </TouchableOpacity>
       
        

     <TouchableOpacity 
          style={styles.btnstyle1}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
 
           <Text>United Kingdom   </Text>
            
  </TouchableOpacity>



     <TouchableOpacity 
          style={styles.btnstyle1}
          activeOpacity = { .5 }
          onPress={ this.ButtonClickCheckFunction }
       >
 
           <Text>Paris Area   </Text>
            
  </TouchableOpacity>




      
 </ScrollView>
    </View>




</View> 

<View  style={{flex:1,flexDirection:'row',justifyContent:'center',marginLeft:30}}>

<View  style={{flex:1}}>
 <LinearGradient style={{borderTopLeftRadius:15,borderTopRightRadius:15,width:120,height:30,alignItems:'center',justifyContent:'center'}}
       start={{ x: 0.1, y: 0.1 }} end={{ x: 0.5, y: 0.5 }}
       
       colors={['#dcc642', '#896100', '#f2eb80']}  >
       <Text>Clear all</Text>

</LinearGradient>
</View>
<View  style={{flex:1}}>

  <LinearGradient style={{borderTopLeftRadius:15,borderTopRightRadius:15,width:120,height:30,alignItems:'center',justifyContent:'center'}}
       start={{ x: 0.1, y: 0.1 }} end={{ x: 0.5, y: 0.5 }}
       
       colors={['#dcc642', '#896100', '#f2eb80']}  >
       <Text>Search now</Text>

</LinearGradient>
</View>

</View>
</ScrollView>

  
 </View>


{/*search*********************************************************** */}

<View style={{ flex: 1,
    backgroundColor: '#F5FCFF',zIndex:50}}>
        <BottomSheet
          snapPoints = {[50, 300, 50]}
          renderContent = {this.renderInner}
          renderHeader = {this.renderHeader}
      styles = {{zIndex:50}}
       
        />
       </View>

        {/* <Button
          title="OPEN BOTTOM SHEET"
          onPress={() => {
            this.RBSheet.close();
          }}
        /> */}
        <RBSheet
          ref={ref => {
            this.RBSheet = ref;
          }}
          height={300}
          duration={250}
          customStyles={{
            container: {
              justifyContent: "center",
              alignItems: "center"
            }
          }}
        >

<View style={{flex:2,justifyContent:'center'}}>
  <LinearGradient style={{flex:1,borderTopLeftRadius:30,borderTopRightRadius:30}}
       start={{ x: 0.1, y: 0.1 }} end={{ x: 0.5, y: 0.5 }}
       
       colors={['#dcc642', '#896100', '#f2eb80']}  >

       <ScrollView>
       
           
<View style={{justifyContent:'center', padding:15}}>

          <Text style={styles.fontstyle}>Sexual Preferences </Text>  

   

    <View style={{justifyContent:'center', flexDirection:'row', padding:15}}>
     <LinearGradient style={{flexDirection:'row',width:'80%',justifyContent:'center',height:30,borderRadius:50}}
       
       colors={['#dcc642', '#896100', '#f2eb80']}  >
           <Text>Straight   </Text>
           <Text>Gray   </Text>  
              <Text>Bisexual</Text> 
    </LinearGradient>

    </View>



<View style={{flexDirection:'row'}}>
  <Text style={styles.fontstyle}>Show People within </Text> 
    <Text style={{color:'white',marginTop:3,left:8}}>79 km </Text> 


   </View>

    <View style={{justifyContent:'center', flexDirection:'row', padding:15}}>
     <LinearGradient style={{flexDirection:'row',width:'80%',justifyContent:'center',height:10,borderRadius:50}}
       
       colors={['#dcc642', '#896100', '#f2eb80']}  >
           
    </LinearGradient>

    </View>





    
  <View style={{flexDirection:'row'}}>
  <Text style={styles.fontstyle}>Age limit</Text> 
    <Text style={{color:'white',marginTop:3,left:8}}>28 years </Text> 


   </View>

    <View style={{justifyContent:'center', flexDirection:'row', padding:15}}>
     <LinearGradient style={{flexDirection:'row',width:'80%',justifyContent:'center',height:10,borderRadius:50}}
       
       colors={['#dcc642', '#896100', '#f2eb80']}  >
           
    </LinearGradient>

    </View>



    <View style={{flexDirection:'row'}}>
  <Text style={styles.fontstyle}>Show my age</Text> 
                      <Switch style={{left:180}}
                    onValueChange ={(switchValue)=>this.setState({switchValue})}/> 

   </View>







<View style={{flexDirection:'row',marginTop:10}}>
  <Text style={styles.fontstyle}>Contact Preferences</Text> 


   </View>

    <View style={{flexDirection:'row',marginTop:10}}>
  <Text style={{color:'white'}}>enable email notification</Text> 
                      <Switch style={{left:135}}
                    onValueChange ={(switchValue)=>this.setState({switchValue})}/> 

   </View>



 



<View style={{flexDirection:'row',marginTop:10}}>
  <Text style={{color:'white'}}> Recive monthly Newsletter</Text> 
                      <Switch style={{left:120}}
                    onValueChange ={(switchValue)=>this.setState({switchValue})}/> 

   </View>   






<View style={{flexDirection:'row',marginTop:10}}>
  <Text style={styles.fontstyle}>About</Text> 


   </View>

    <View style={{marginTop:10}}>
  <Text style={{color:'white'}}>Term of use</Text> 
                      
  <Text style={{color:'white',marginTop:10}}>Privacy policy</Text> 
    <Text style={{color:'white',marginTop:10}}> Get support</Text> 


   </View>





   <View style={{flexDirection:'row',marginTop:10}}>
  <Text style={styles.fontstyle}>Acount</Text> 


   </View>

    <View style={{marginTop:10}}>
  <Text style={{color:'white'}}>Change Email Address</Text> 
                      
  <Text style={{color:'white',marginTop:10}}>Change Password</Text> 
    <Text style={{color:'white',marginTop:10}}> Logout</Text> 


   </View>

</View>








</ScrollView>
 </LinearGradient>
  
 </View>

 </RBSheet>
      
    </View>
    
 
  
    
  );
};
}

const styles = StyleSheet.create({


 btnstyle1:{borderRadius:50,borderWidth:1,height:30,width:120,alignItems:'center',justifyContent:'center',marginRight:8}
  ,


  btnstyle:{borderRadius:50,borderWidth:1,height:30,width:80,alignItems:'center',justifyContent:'center',marginRight:8}
  ,
  fontstyle:{color:'white',fontSize:18},
  container: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: '#f2f2f2',
  },
  content:{
    flex: 5,
    marginBottom:70,
    alignItems: 'center',
    justifyContent: 'center',
  },
  card:{
    width: 320,
    height: 470,
    backgroundColor: '#FE474C',
    borderRadius: 5,
    shadowColor: 'rgba(0,0,0,0.5)',
    shadowOffset: {
      width: 0,
      height: 1
    },
    shadowOpacity:0.5,
  },
  card1: {
    backgroundColor: '#FE474C',
  },
  card2: {
    backgroundColor: '#FEB12C',
  },
  label: {
    lineHeight: 400,
    textAlign: 'center',
    fontSize: 55,
    fontFamily: 'System',
    color: '#ffffff',
    backgroundColor: 'transparent',
  },
  footer:{
    flex:1,
    justifyContent:'center',
    alignItems:'center'
  },
  buttonContainer:{
    width:220,
    flexDirection:'row',
    justifyContent: 'space-between',
  },
  button:{
    shadowColor: 'rgba(0,0,0,0.3)',
    shadowOffset: {
      width: 0,
      height: 1
    },
    shadowOpacity:0.5,
    backgroundColor:'#fff',
    alignItems:'center',
    justifyContent:'center',
    zIndex: 0,
  },
  orange:{
    width:55,
    height:55,
    borderWidth:6,
    borderColor:'rgb(246,190,66)',
    borderRadius:55,
    marginTop:-15
  },
  green:{
    width:75,
    height:75,
    backgroundColor:'#fff',
    borderRadius:75,
    borderWidth:6,
    borderColor:'#01df8a',
  },
  red:{
    width:75,
    height:75,
    backgroundColor:'#fff',
    borderRadius:75,
    borderWidth:6,
    borderColor:'#fd267d',
  },
  rotatingimage:{
    //flex:1,
    height:40,
    width:40,
   // marginTop:20,
    //paddingLeft: 15,
    //paddingRight: 15,
    //marginLeft:20,
    //marginRight:220,

  },
  rotatingcontainer:{
    flex:1,
    flexDirection:'row',
    height:70,
  
  },
  label1:{
    flex:1,
    //marginTop:0,
    //paddingLeft: 20,
    marginLeft:30,
    lineHeight: 400,
    textAlign: 'center',
    fontSize: 20,
    fontFamily: 'System',
    color: '#ffffff',
    backgroundColor: 'transparent',
  },
  linearGradient1:{
    //flex: 1,
    flexDirection:'row',
    height:60,
    //width:'100%',
    //marginTop:150,
    //marginBottom:200,
    //paddingLeft: 15,
    //paddingRight: 15,
    //marginLeft:20,
    //marginRight:20,
    //alignItems:'center',
    //justifyContent:'center',
  },
  tickimage1:{
    height:40,
    width:40,
    marginTop:15,
    paddingLeft: 15,
    paddingRight: 15,
    marginLeft:20,
    marginRight:20,
  },
  soundimage:{
    height:50,
    width:50,
    marginTop:15,
    justifyContent:'center',
    alignItems:'center',
    //paddingLeft: 15,
    //paddingRight: 15,
    marginLeft:140,
    //marginRight:20,
  },
  lovelyimage:{
    
    height:20,
    width:20,
    marginTop:15,

    //justifyContent:'center',
    //alignItems:'center',
    //marginLef:20,
    //paddingLeft: 15,
    //paddingRight: 15,
   // marginLeft:140,
    //marginRight:20,
  },
  coffeeimage:{
    
    height:20,
    width:20,
    marginTop:40,
    marginRight:20
    //justifyContent:'center',
    //alignItems:'center',
    //marginLef:20,
    //paddingLeft: 15,
    //paddingRight: 15,
   // marginLeft:140,
    //marginRight:20,
  },
  texaccount2:{
    flexDirection:'row',
    marginTop:25,
    fontSize:15,
    //paddingLeft: 15,
    paddingRight: 15,
   // marginLeft:20,
    marginRight:20,
    color:'white'
  },
  tickimage2:{
    //flex:1,
    //justifyContent:'flex-end',
    //flexDirection:'row',
    //alignItems:'center',
   height:30,
    width:20,
    marginTop:15,
    paddingLeft: 15,
    paddingRight: 15,
   // marginLeft:20,
    marginRight:20,
  },
  rightcontainer:{
    flex:1,
    flexDirection:'row',
    justifyContent:'flex-end',
    alignItems:'center'
  },
  searchimage:{
    
    height:20,
    width:'5%',
    marginTop:25,
    //paddingLeft:20,
    paddingLeft: 10,
    paddingRight: 10,
    marginLeft:20,
    marginRight:20,
    
    
  },
  searchimage1:{
    
    height:30,
    width:'10%',
    marginTop:25,
    //paddingLeft:20,
    //paddingLeft: 10,
    //paddingRight: 10,
    marginLeft:15,
    marginRight:15,
    
    
  },
  imgviewcontainer:{
    //height:'30%',
    flexDirection:'row',
    paddingLeft:'5%',
   // marginBottom:80,
    flex:1,
    backgroundColor:'#252525'
  },
  Txtdiscover:{
    color:'#dcc642',
    paddingLeft:'10%',
    fontSize:15,
    flex:1,
    marginTop:25
  },
  Txtdiscoverstraight:{
    color:'white',
    //paddingLeft:'5%',
    fontSize:18,
    flex:1,
    marginTop:25,
     marginLeft:10,
    marginRight:12,
  },
  Txtpune:{
    color:'black',
    //paddingLeft:'5%',
    fontSize:18,
    flex:1,
    marginTop:25,
     marginLeft:10,
    marginRight:12,
  },
  Txtdiscoversingle:{
    color:'white',
    //paddingLeft:'5%',
    fontSize:18,
    flex:1,
    marginTop:25,
     marginLeft:7,
    marginRight:2,
  },
  Txtoctomber:{
    color:'black',
    //paddingLeft:'5%',
    fontSize:18,
    flex:1,
    marginTop:25,
     marginLeft:7,
    marginRight:2,
  },
  compassimage:{
    
    height:20,
    width:'5%',
    marginTop:25,
    
    paddingLeft: 10,
    paddingRight: 10,
    marginLeft:45,
    //marginRight:30,
    
    
  },
  label:{
    flex:1,
    marginTop:-180,
    paddingLeft:20
  },
  imgviewcontainercard:{
    //height:'30%',
    flexDirection:'row',
    paddingLeft:'5%',
    marginBottom:80,
    flex:1,
   // backgroundColor:'#252525'
  },
  scrollviewcontainercard:{
    marginTop:20,
    //height:'30%',
    flexDirection:'row',
    paddingLeft:'5%',
    marginBottom:80,
    flex:1,
   // backgroundColor:'#252525'
  },
  scrollviewcontainer:{
    height:80,
    backgroundColor:'white',
    borderTopLeftRadius:30,
    borderTopRightRadius:30
    
  },
   panelContainer: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
  panel: {
    height: 600,
    //padding: 20,
    backgroundColor: '#dcc642',
  },
  header: {
    backgroundColor: '#dcc642',
    shadowColor: '#000000',
    paddingTop: 15,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    //height:10,
  },
  panelHeader: {
    alignItems: 'center',
  },
  panelHandle: {
    width: 40,
    height:8,
    marginTop:10,
    marginBottom:10,
    borderRadius: 4,
    backgroundColor: '#00000040',
   // marginBottom: 10,
  },
  panelTitle: {
    fontSize: 27,
    height: 35,
  },
  panelSubtitle: {
    fontSize: 14,
    color: 'gray',
    height: 30,
    marginBottom: 10,
  },
  panelButton: {
    padding: 20,
    borderRadius: 10,
    backgroundColor: '#318bfb',
    alignItems: 'center',
    marginVertical: 10,
  },
  panelButtonTitle: {
    fontSize: 17,
    fontWeight: 'bold',
    color: 'white',
  },
  tabbarcontainer1:{
    flex:1,
    flexDirection:'column',
    //height:70,
    //backgroundColor:'white',
    //alignItems:'center'
   
  }
  

});

