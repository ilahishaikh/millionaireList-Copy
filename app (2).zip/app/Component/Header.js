 Header = () =>
 {
     return   ('<Text style={styles.TextStyle} >Add Your Profile Info </Text> ') ;
 }



 export default Header
