import React, { Component } from 'react';
import { connect } from "react-redux";

import {
    SafeAreaView,
    StyleSheet,
    ScrollView,
    View,
    Text,
    Button,
    TextInput,
    StatusBar,
    TouchableOpacity,
    ImageBackground,
    Image,propTypes,
} from 'react-native';
import LinkedLoginContainer from './LinkedLoginContainer.js'
import LinearGradient from 'react-native-linear-gradient';
class Singupconfirm extends React.Component {
    constructor(props) {
        super(props);
        this.handleClick1 = this.handleClick1.bind(this);
   
    
      }
    
      handleClick1 = () => {
        console.log(this);
        this.props.onChange();


    }
    showAlert = () =>
    {
  
   
     this.props.navigation.navigate('Verification');
    }
      
    render(){
        return (
            <View style={{backgroundColor:'black',width:'100%',flex:1}}>
                <ScrollView>
                    <Text style={styles.txtcreate} > Create an account to save your information: </Text>
        <View style={{marginTop:80}}>             
        <TextInput style={styles.tntxtstyle}  placeholder="Email address"
        placeholderTextColor = "#dcc642"  /> 
        <TextInput style={styles.tntxtstyle}  placeholder="Password"
        placeholderTextColor = "#dcc642"  /> 
        <TextInput style={styles.tntxtstyle}  placeholder="Confirm Password"
        placeholderTextColor = "#dcc642"  /> 
        </View>
        <LinearGradient 
       start={{ x: 0.9, y: 0 }} end={{ x: 0, y: 0 }}
       
       colors={['#dcc642', '#896100', '#f2eb80']} style={styles.linearGradient}>
          <TouchableOpacity
              style={styles.describebtnStyle}
              activeOpacity = { .5 }
              onPress={ this.showAlert }
           >
  <Text style={styles.buttonText}>
Sign  In  </Text>
</TouchableOpacity> 
</LinearGradient>
        </ScrollView>
</View>

        )
        
    }
}
const styles = StyleSheet.create({
    tntxtstyle:{
      flex:1,
      fontFamily:'FontAwesome',
      fontSize:15,
         height:40,
        paddingLeft: 20,
          color:'#dcc642',
          backgroundColor:'gray',
          width:'90%',
           marginLeft:'5%',
        //   paddingLeft:'5%',
          //marginRight:'10%',
          marginTop:20,
          borderRadius:50,
          borderWidth:2,
          borderColor:'gray'
    },
    txtcreate:{
      color:'#dcc642',
      fontFamily:'FontAwesome',
      fontSize:16,
      marginTop:90,
        textAlign:'center',
        padding:10
    },
    buttonContainer:{
        flex: 1,
            height:40,
            width:"50%",
          
           
            paddingTop:10,
            paddingBottom:20,
            marginLeft:'25%',
           // marginRight:10,
          
            borderRadius:10,
            borderColor: '#17202A',
            borderWidth: 1,
            //flexDirection: 'row',
            paddingLeft:"3%",
            paddingRight:"3%",
            marginTop:20,
            backgroundColor:'#17202A',
    },
    TextStylechadd:{
        textAlign:'center',
        color:'white'
    },
    linearGradient:{

      flex:1,
      width:'90%',
      marginLeft:20,
           height: 40,
           marginTop:20,
          paddingLeft: 80,
          paddingRight: 80,
          borderRadius: 50,
          //marginBottom:1,
          //marginTop: "-1%",
      //textTransform: 'none'
        },
        buttonText:{
      
           textAlign:'center',
           
            marginTop:'5%',
            fontFamily:'FontAwesome',
            fontSize: 20,
           
      
        },

});
const mapStateToProps = state => ({
    loading: state.auth.loading,
    isAuthorised: state.auth.isAuthorised,
    eid: state.auth.eid,
    auth: state.auth,
    uid: state.auth.uid
  });
  
  const mapDispatchToProps = dispatch => ({
    fbLogin: payload => dispatch(AuthActions.fbLogin(payload)),
    requestLogin: () => dispatch(AuthActions.requestLogin()),
    showStatusBar: (type, title, message) =>
      dispatch(StatusBarActions.showStatusBar(type, title, message))
  });
  
  export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(Singupconfirm);
