/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  TouchableOpacity,
  Image,
  FlatList,Switch
  
} from 'react-native';

import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import ic_tick from '../assets/ic_tick.png'
import CardStack, { Card } from 'react-native-card-stack-swiper';
import rotating from '../assets/rotating.png'
import ic_message from '../assets/ic_message.png'
import user_profile from '../assets/user_profile.png'
import LinearGradient from 'react-native-linear-gradient';
import searchgolden from '../assets/searchgolden.png'
import directional from '../assets/directional.png'
import mars from '../assets/mars.png'
import sound from '../assets/sound.png'
import lovely from '../assets/lovely.png'
import coffee from '../assets/coffee.png'
import body from '../assets/body.png'
import place from '../assets/place.png'
import glass from '../assets/glass.png'
import ic_camera from '../assets/ic_camera.png'
import ic_linked_in from '../assets/ic_linked_in.png'
import education from '../assets/education.png'
import ic_up_quotes from '../assets/education.png'

import BottomSheet from 'reanimated-bottom-sheet'

import msg from '../assets/msg.png'
import flash from '../assets/flash.png'
import ic_reswipe from '../assets/ic_reswipe.png'




const DATA = [
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'First Item',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'Second Item',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'Third Item',
  },
];
export default class Discover extends React.Component{
 
 
  constructor(props) {
    super(props);
  //  initState = 
     this.state = {
        search:'Discover',
        discover:'No',
        timeline:'No',
        timeline:'No',   
    };
     //  this.handlerButtonOnClick = this.handlerButtonOnClick.bind(this);

  }

  handlerButtonOnClick(tmp1){
       

  this.setState({
    search: tmp1
 });
  
  }
 
 
  navigateToMessage = () =>
  {

 
   this.props.navigation.navigate('msglist');
  }
  navigateToEdit= () =>
  {

 
   this.props.navigation.navigate('Editprodile');
  }
     
  renderInner = () => (
    <View style={styles.panel}>
      
<View style={{flex:1,justifyContent:'center'}}>
  <LinearGradient
       start={{ x: 0.1, y: 0.1 }} end={{ x: 0.5, y: 0.5 }}
       
       colors={['#dcc642', '#896100', '#f2eb80']}  >

      
       
           
<View style={{justifyContent:'center', padding:15}}>

          <Text style={styles.fontstyle}>Sexual Preferences </Text>  

   

    <View style={{justifyContent:'center', flexDirection:'row'}}>
     <LinearGradient style={{flexDirection:'row',width:'100%',justifyContent:'center',height:30,borderRadius:50}}
       
       colors={['#dcc642', '#896100', '#f2eb80']}  >
           <Text>Straight   </Text>
           <Text>Gray   </Text>  
              <Text>Bisexual</Text> 
    </LinearGradient>

    </View>



<View style={{flexDirection:'row'}}>
  <Text style={styles.fontstyle}>Show People within </Text> 
    <Text style={{color:'white',marginTop:3,left:8}}>79 km </Text> 


   </View>

    <View style={{justifyContent:'center', flexDirection:'row', padding:15}}>
     <LinearGradient style={{flexDirection:'row',width:'80%',justifyContent:'center',height:10,borderRadius:50}}
       
       colors={['#dcc642', '#896100', '#f2eb80']}  >
           
    </LinearGradient>

    </View>





    
  <View style={{flexDirection:'row'}}>
  <Text style={styles.fontstyle}>Age limit</Text> 
    <Text style={{color:'white',marginTop:3,left:8}}>28 years </Text> 


   </View>

    <View style={{justifyContent:'center', flexDirection:'row', padding:15}}>
     <LinearGradient style={{flexDirection:'row',width:'80%',justifyContent:'center',height:10,borderRadius:50}}
       
       colors={['#dcc642', '#896100', '#f2eb80']}  >
           
    </LinearGradient>

    </View>



    <View style={{flexDirection:'row'}}>
  <Text style={styles.fontstyle}>Show my age</Text> 
                      <Switch style={{left:180}}
                    onValueChange ={(switchValue)=>this.setState({switchValue})}/> 

   </View>







<View style={{flexDirection:'row',marginTop:10}}>
  <Text style={styles.fontstyle}>Contact Preferences</Text> 


   </View>

    <View style={{flexDirection:'row',marginTop:10}}>
  <Text style={{color:'white'}}>enable email notification</Text> 
                      <Switch style={{left:135}}
                    onValueChange ={(switchValue)=>this.setState({switchValue})}/> 

   </View>



 



<View style={{flexDirection:'row',marginTop:10}}>
  <Text style={{color:'white'}}> Recive monthly Newsletter</Text> 
                      <Switch style={{left:120}}
                    onValueChange ={(switchValue)=>this.setState({switchValue})}/> 

   </View>   






<View style={{flexDirection:'row',marginTop:10}}>
  <Text style={styles.fontstyle}>About</Text> 


   </View>

    <View style={{marginTop:10}}>
  <Text style={{fontFamily:'FontAwesome',fontSize:15,color:'white'}}>Term of use</Text> 
                      
  <Text style={{fontFamily:'FontAwesome',fontSize:15,color:'white',marginTop:10}}>Privacy policy</Text> 
    <Text style={{fontFamily:'FontAwesome',fontSize:15,color:'white',marginTop:10}}> Get support</Text> 


   </View>





   <View style={{flexDirection:'row',marginTop:10}}>
  <Text style={styles.fontstyle}>Acount</Text> 


   </View>

    <View style={{marginTop:10}}>
  <Text style={{color:'white'}}>Change Email Address</Text> 
                      
  <Text style={{color:'white',marginTop:10}}>Change Password</Text> 
    <Text style={{color:'white',marginTop:10}}> Logout</Text> 


   </View>

</View>









 </LinearGradient>
  
 </View>

     
    </View>
  )

  renderHeader = () => (
    <View style={styles.header}>

<View style={{flex:1,flexDirection:'row',justifyContent:'center',alignItems:'center'}}>
          
          <View style={{flex:1,flexDirection:'row',marginLeft:50}}>
          <Image source={ic_reswipe}style={{width:30,height:30} } />
            </View>
  
            <View style={{flex:1,flexDirection:'row'}}>
            <Image source={msg} style={{width:30,height:30} } />

            </View>
  
            <View style={{flex:1,flexDirection:'row',}}>
            <Image source={flash} style={{width:30,height:30,} } />

            
          </View>
  
          </View>
  
      {/* <View style={styles.panelHeader}>
        
        <View style={styles.panelHandle} />


              </View> */}
    </View>
  )
  render(){
    const elements = ['one', 'two', 'three'];
  var  istimeline = false;
  var  isdiscover = false;
  var issearch = false;
    if(this.state.search == 'Timeline')
    {
      istimeline = true;
    }
    else if(this.state.search == 'Discover')
    {
      isdiscover = true;
    }
    if(this.state.search == 'search')
    {
      issearch = true;
    }
    return (

<View style={{ flex: 1 }}>
{/* <LinearGradient 
       start={{ x: 0.1, y: 0.1 }} end={{ x: 0.5, y: 0.5 }}
       
       colors={['#dcc642', '#896100', '#f2eb80']} style={styles.linearGradient1}>
       
  <Image source={user_profile} style={styles.tickimage1  } />
  
  <Text style={styles.texaccount2}> 
  your profile</Text>
  <View style={styles.rightcontainer}>
  <Image source={ic_message} style={styles.tickimage2  } />
</View>
</LinearGradient> */}
{/* <View style={styles.imgviewcontainer}>
<TouchableOpacity
         
          activeOpacity = { .5 }
          onPress={this.handlerButtonOnClick.bind(this,'search')}
       >

<Image source={searchgolden} style={styles.searchimage  } />
</TouchableOpacity>

<TouchableOpacity
         
          activeOpacity = { .5 }
          onPress={this.handlerButtonOnClick.bind(this,'Discover')}
       >
 
        <Text style={styles.Txtdiscover}>Discover </Text>
            
  </TouchableOpacity>
  <TouchableOpacity
         
         activeOpacity = { .5 }
         onPress={this.handlerButtonOnClick.bind(this,'Timeline')}
      >
 
        <Text style={styles.Txtdiscover}>Timeline</Text>
        
        
            
  </TouchableOpacity>
  <TouchableOpacity
         
         activeOpacity = { .5 }
         onPress={this.handlerButtonOnClick.bind(this,'Compass')}
      >
 
  <Image source={directional} style={styles.compassimage  } />
  </TouchableOpacity>
</View> */}


<View style={{flex:5,marginTop:60,zIndex:2}} >
      <CardStack
        style={styles.content}
        renderNoMoreCards={() => <Text style={{ fontWeight: '700', fontSize: 18, color: 'gray' }}>No more cards :(</Text>}
        ref={swiper => {
          this.swiper = swiper
        }}
        onSwiped={() => console.log('onSwiped')}
        onSwipedLeft={() => console.log('onSwipedLeft')}
      >

        
      
        <Card style={[styles.card, styles.card1]}>
      
        <View style={styles.imgviewcontainercard}>
<Image
 source={mars} style={styles.searchimage1  } />
<View style={{borderLeftWidth:1,borderLeftColor:'white',height:30,marginTop:25}}/>

 
        <Text style={styles.Txtdiscoverstraight}>Straight </Text>
        <View style={{borderLeftWidth:1,borderLeftColor:'white',height:30,marginTop:25}}/>    
  {/*</TouchableOpacity>*/}
  
 {/*<View style={{borderLeftWidth:1,borderLeftColor:'white',height:30,marginTop:25}}/>*/}
        <Text style={styles.Txtdiscoversingle}>Single</Text>
            
  
  
  <View style={{borderLeftWidth:1,borderLeftColor:'white',height:30,marginTop:25}}/>
        <Text style={styles.Txtdiscoverstraight}>85Km</Text>
        

</View>

<ScrollView style={styles.scrollviewcontainer}>
        <Text style={{fontFamily:'FontAwesome',fontSize:15,textAlign:'center', color:'black',marginTop:10}}>Ritvik Sexsena</Text>
        <Text style={{fontFamily:'FontAwesome',fontSize:15,textAlign:'center', color:'black',marginTop:20,fontSize:20}}>CEO</Text>

        <View style={styles.scrollviewcontainercard}>
<Text style={styles.Txtoctomber}>5 Oct</Text>
<View style={{borderLeftWidth:1,borderLeftColor:'black',height:30,marginTop:25}}/>

 
        <Text style={styles.Txtpune}>Pune </Text>
        <View style={{borderLeftWidth:1,borderLeftColor:'black',height:30,marginTop:25}}/>    
 
  

        <Text style={styles.Txtpune}>5.11</Text>
            
  
  {/*<Image source={directional} style={styles.compassimage  } />*/}
  <View style={{borderLeftWidth:1,borderLeftColor:'black',height:30,marginTop:25}}/>
        <Text style={styles.Txtpune}>50K+</Text>
        

</View>



<Text style={{fontFamily:'FontAwesome',color:'black', textAlign:'center',marginTop:-70,fontSize:15}}>Hindi,English,French</Text>
<Image source={sound} style={styles.soundimage  } />
<Text style={{fontFamily:'FontAwesome',color:'black', textAlign:'center',fontSize:15}}>
"2 indivisual with same passion makes me happy "</Text>


<View style={{flexDirection:'row'}}>
<Image source={lovely} style={{height:20,width:20,marginLeft:60,marginTop:6}} />
<Text style={{fontFamily:'FontAwesome',color:'black', textAlign:'center',fontSize:15,marginTop:5,
borderBottomColor:'#dcc642',marginLeft:10}}>

Looking for serious relationship.</Text>
</View>
<Text style={{color:'black', 
borderBottomWidth:2,borderBottomColor:'#dcc642',
}}> </Text>

<View style={{flexDirection:'row'}}>
<Image source={coffee} style={{height:20,width:20,marginLeft:70,marginTop:6}} />
  <Text style={{fontFamily:'FontAwesome',color:'black', textAlign:'center',fontSize:15,marginTop:10,
  borderBottomColor:'#dcc642',marginLeft:15}}>Prefer to meet over coffee </Text>
</View>
<Text style={{color:'black', 
borderBottomWidth:2,borderBottomColor:'#dcc642',
}}> </Text>
<View style={{flexDirection:'row'}}>
<Image source={education} style={{height:25,width:30,marginLeft:30,marginTop:6}} />

{/*<View style={{flexDirection:'row',borderBottomWidth:2,borderBottomColor:'#dcc642',marginTop:10}}>*/}
<Text style={{fontFamily:'FontAwesome',color:'black', textAlign:'center',fontSize:15,marginLeft:5,marginTop:8}}>

Bteck</Text>
<Image source={body} style={{height:25,width:25,marginLeft:70,marginTop:5}} />

<Text style={{fontFamily:'FontAwesome',color:'black', textAlign:'center',fontSize:15,marginLeft:5,marginTop:6}}>Average, Brown</Text>

</View>
<Text style={{color:'black', 
borderBottomWidth:2,borderBottomColor:'#dcc642',
}}> </Text>

<View style={{flexDirection:'row'}}>
<Image source={place} style={{height:25,width:25,marginLeft:30,marginTop:6}} />

{/*<View style={{flexDirection:'row',borderBottomWidth:2,borderBottomColor:'#dcc642',marginTop:10}}>*/}
<Text style={{fontFamily:'FontAwesome',color:'black', textAlign:'center',fontSize:15,marginLeft:5,marginTop:9}}>

Leaving with friends</Text>
<Image source={glass} style={{height:25,width:25,marginTop:6}} />

<Text style={{fontFamily:'FontAwesome',color:'black', textAlign:'center',fontSize:15,marginTop:6}}>Ocassionally</Text>


</View>
<View style={{flexDirection:'row'}}>
<Image source={ic_linked_in} style={{height:40,width:40,marginLeft:110,marginTop:6,justifyContent:'center'}} />
<Image source={ic_camera} style={{height:40,width:40,marginLeft:30,marginTop:6}} />
</View>
<Text style={{textAlign:'center', fontSize:13,marginTop:6}}> Report this User</Text>

    </ScrollView>

        
        </Card>
        
        
        
        <Card style={[styles.card, styles.card1]}><Text style={styles.label}>E</Text></Card>
      
      
        </CardStack>
        </View>
      <View style={{ flex: 1,
    backgroundColor: '#F5FCFF',zIndex:50}}>
        <BottomSheet
          snapPoints = {[50, 300, 50]}
          renderContent = {this.renderInner}
          renderHeader = {this.renderHeader}
      styles = {{zIndex:50}}
       
        />

        
       
       </View>

     
    </View>
    
 
  
    
  );
};
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: '#f2f2f2',
  },
  content:{
    flex: 1,
    
    alignItems: 'center',
    justifyContent: 'center',
  },
  card:{
    width: 320,
    height: 470,
    backgroundColor: '#FE474C',
    borderRadius: 5,
    shadowColor: 'rgba(0,0,0,0.5)',
    shadowOffset: {
      width: 0,
      height: 1
    },
    shadowOpacity:0.5,
  },
  card1: {
    backgroundColor: '#FE474C',
  },
  card2: {
    backgroundColor: '#FEB12C',
  },
  label: {
    lineHeight: 400,
    textAlign: 'center',
    fontSize: 55,
    fontFamily: 'System',
    color: '#ffffff',
    backgroundColor: 'transparent',
  },
  footer:{
    flex:1,
    
    position: 'absolute',
    transform: [{'translate': [0,0, 1]}]
  },
  buttonContainer:{
    width:220,
    flexDirection:'row',
    justifyContent: 'space-between',
  },
  button:{
    shadowColor: 'rgba(0,0,0,0.3)',
    shadowOffset: {
      width: 0,
      height: 1
    },
    shadowOpacity:0.5,
    backgroundColor:'#fff',
    alignItems:'center',
    justifyContent:'center',
    zIndex: 0,
  },
  orange:{
    width:55,
    height:55,
    borderWidth:6,
    borderColor:'rgb(246,190,66)',
    borderRadius:55,
    marginTop:-15
  },
  green:{
    width:75,
    height:75,
    backgroundColor:'#fff',
    borderRadius:75,
    borderWidth:6,
    borderColor:'#01df8a',
  },
  red:{
    width:75,
    height:75,
    backgroundColor:'#fff',
    borderRadius:75,
    borderWidth:6,
    borderColor:'#fd267d',
  },
  rotatingimage:{
    //flex:1,
    height:40,
    width:40,
   // marginTop:20,
    //paddingLeft: 15,
    //paddingRight: 15,
    //marginLeft:20,
    //marginRight:220,

  },
  rotatingcontainer:{
    flex:1,
    flexDirection:'row',
    height:70,
  
  },
  label1:{
    flex:1,
    //marginTop:0,
    //paddingLeft: 20,
    marginLeft:30,
    lineHeight: 400,
    textAlign: 'center',
    fontSize: 20,
    fontFamily: 'System',
    color: '#ffffff',
    backgroundColor: 'transparent',
  },
  linearGradient1:{
    //flex: 1,
    flexDirection:'row',
    height:60,
    //width:'100%',
    //marginTop:150,
    //marginBottom:200,
    //paddingLeft: 15,
    //paddingRight: 15,
    //marginLeft:20,
    //marginRight:20,
    //alignItems:'center',
    //justifyContent:'center',
  },
  tickimage1:{
    height:40,
    width:40,
    marginTop:15,
    paddingLeft: 15,
    paddingRight: 15,
    marginLeft:20,
    marginRight:20,
  },
  soundimage:{
    height:50,
    width:50,
    marginTop:15,
    justifyContent:'center',
    alignItems:'center',
    //paddingLeft: 15,
    //paddingRight: 15,
    marginLeft:140,
    //marginRight:20,
  },
  lovelyimage:{
    
    height:20,
    width:20,
    marginTop:15,

    //justifyContent:'center',
    //alignItems:'center',
    //marginLef:20,
    //paddingLeft: 15,
    //paddingRight: 15,
   // marginLeft:140,
    //marginRight:20,
  },
  coffeeimage:{
    
    height:20,
    width:20,
    marginTop:40,
    marginRight:20
    //justifyContent:'center',
    //alignItems:'center',
    //marginLef:20,
    //paddingLeft: 15,
    //paddingRight: 15,
   // marginLeft:140,
    //marginRight:20,
  },
  texaccount2:{
    flexDirection:'row',
    marginTop:25,
    fontSize:15,
    //paddingLeft: 15,
    paddingRight: 15,
   // marginLeft:20,
    marginRight:20,
    color:'white'
  },
  tickimage2:{
    //flex:1,
    //justifyContent:'flex-end',
    //flexDirection:'row',
    //alignItems:'center',
   height:30,
    width:20,
    marginTop:15,
    paddingLeft: 15,
    paddingRight: 15,
   // marginLeft:20,
    marginRight:20,
  },
  rightcontainer:{
    flex:1,
    flexDirection:'row',
    justifyContent:'flex-end',
    alignItems:'center'
  },
  searchimage:{
    
    height:20,
    width:'5%',
    marginTop:25,
    //paddingLeft:20,
    paddingLeft: 10,
    paddingRight: 10,
    marginLeft:20,
    marginRight:20,
    
    
  },
  searchimage1:{
    
    height:30,
    width:'10%',
    marginTop:25,
    //paddingLeft:20,
    //paddingLeft: 10,
    //paddingRight: 10,
    marginLeft:15,
    marginRight:15,
    
    
  },
  imgviewcontainer:{
    //height:'30%',
    flexDirection:'row',
    paddingLeft:'5%',
   // marginBottom:80,
   height:60,
   // flex:1,
    backgroundColor:'#252525'
  },
  Txtdiscover:{
    color:'#dcc642',
    paddingLeft:'10%',
    fontSize:15,
    flex:1,
    marginTop:25
  },
  Txtdiscoverstraight:{
    color:'white',
    //paddingLeft:'5%',
    fontSize:18,
    flex:1,
    marginTop:25,
     marginLeft:10,
    marginRight:12,
  },
  Txtpune:{
    color:'black',
    //paddingLeft:'5%',
    fontSize:18,
    flex:1,
    marginTop:25,
     marginLeft:10,
    marginRight:12,
  },
  Txtdiscoversingle:{
    color:'white',
    //paddingLeft:'5%',
    fontSize:18,
    flex:1,
    marginTop:25,
     marginLeft:7,
    marginRight:2,
  },
  Txtoctomber:{
    color:'black',
    //paddingLeft:'5%',
    fontSize:18,
    flex:1,
    marginTop:25,
     marginLeft:7,
    marginRight:2,
  },
  compassimage:{
    
    height:20,
    width:'5%',
    marginTop:25,
    
    paddingLeft: 10,
    paddingRight: 10,
    marginLeft:45,
    //marginRight:30,
    
    
  },
  label:{
    flex:1,
    marginTop:-180,
    paddingLeft:20
  },
  imgviewcontainercard:{
    //height:'30%',
    flexDirection:'row',
    paddingLeft:'5%',
    marginBottom:80,
    flex:1,
   // backgroundColor:'#252525'
  },
  scrollviewcontainercard:{
    marginTop:20,
    //height:'30%',
    flexDirection:'row',
    paddingLeft:'5%',
    marginBottom:80,
    flex:1,
   // backgroundColor:'#252525'
  },
  scrollviewcontainer:{
    height:80,
    backgroundColor:'white',
    borderTopLeftRadius:30,
    borderTopRightRadius:30
    
  },
  
  panelContainer: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
  panel: {
    height: 600,
    //padding: 20,
    backgroundColor: '#dcc642',
  },
  header: {
    backgroundColor: '#dcc642',
    shadowColor: '#000000',
    paddingTop: 15,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    //height:10,
  },
  panelHeader: {
    alignItems: 'center',
  },
  panelHandle: {
    width: 40,
    height: 30,
    borderRadius: 4,
    backgroundColor: '#00000040',
   // marginBottom: 10,
  },
  panelTitle: {
    fontSize: 27,
    height: 35,
  },
  panelSubtitle: {
    fontSize: 14,
    color: 'gray',
    height: 30,
    marginBottom: 10,
  },
  panelButton: {
    padding: 20,
    borderRadius: 10,
    backgroundColor: '#318bfb',
    alignItems: 'center',
    marginVertical: 10,
  },
  panelButtonTitle: {
    fontSize: 17,
    fontWeight: 'bold',
    color: 'white',
  },
  photo: {
    width: '100%',
    height: 225,
    marginTop: 30,
  },
  fontstyle:{
  fontFamily:'FontAwesome',fontSize:15
}
});

