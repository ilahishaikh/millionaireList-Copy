import React, { Component } from "react";
import {
  View,
  Text,
  Image,
Button,
  StyleSheet,
  ImageBackground,
  ScrollView,
  TextInput,
  TouchableOpacity,
  
  Dimensions
} from "react-native";
import { connect } from "react-redux";
import  bgImage from '../assets/app_back_img.png'
import logo from '../assets/app_logo.png'
import LinearGradient from 'react-native-linear-gradient';
import { LinearTextGradient } from "react-native-text-gradient";

class DemoScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
     alreadyText:'Already on Millionaire list? Sign in',
      whenText:'when you sign in with ml you agree',
      withText:'with our t&c and privacy policy.'


      
    };
  }
  
//Dont change  
  componentDidMount() {
 
   };

  getQueryString(field, url) {
    const reg = new RegExp('[?&]' + field + '=([^&#]*)', 'i');
    const string = reg.exec(url);
    return string ? string[1] : null;
  }
   showAlert = () =>
  {
    this.props.navigation.navigate('Step1');
  }
  navigate = (screenName, params) => () =>
  this.props.navigation.navigate(screenName, params);

  render() {
  
    
         
      return(
        <ImageBackground source={bgImage} style={styles.backgroundContainer}>
          
        <ScrollView style={{width:"100%"}} scrollEnabled={false}>
         <View style={styles.logoContainer}>
         <Image source={logo} style={styles.logo} />
         <LinearTextGradient
    style={{ fontWeight: "bold", fontSize: 72,marginBottom:"3%", }}
    locations={[0, 1]}
    colors={["#dcc642", "#896100"]}
    start={{ x: 0.5, y: 0.5 }}
    end={{ x: 1, y: 1 }}
  >
          <Text style={styles.logoText}>The Glamorous side of you</Text>
       </LinearTextGradient>

       <LinearGradient 
       start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0 }}
       
       colors={['#dcc642', '#896100', '#f2eb80']} style={styles.linearGradient}>
  <Text style={styles.buttonText}>
  Sign Up with LinkedIn
  </Text>
</LinearGradient>
<TouchableOpacity onPress={this.showAlert} style={{width:'100%'}} >
<Text style={styles.tntxtstyle1} 


             > Create My Account</Text>
             </TouchableOpacity>
            
            <View style={styles.underline}></View>
            <View style={styles.alreadyText}>
             <Text style={{color:"white"}}  >
             Already on Millionaire list? <Text style={{color:"#ded776"}}  >
           Sign in
</Text>
</Text></View>
<View style={styles.whenText}>

<Text style={styles.whenText} onPress={this.onPressTitle}>
          {this.state.whenText}
</Text>
<Text style={styles.withText} onPress={this.onPressTitle}>
with our  <Text style={{color:"#ded776"}}  >t&c</Text>  and  <Text style={{color:"#ded776"}}  >privacy policy</Text>
</Text>
</View>
        
      
       </View>
       
       </ScrollView>
      </ImageBackground>
      
    );
  }
}






//       <View style={styles.container}>
//         {/* <Button title='kkkk' onPress={this.showAlert} style={{backgroundColor: 'yellow'}} ></Button>
//  */}

       

//       </View>


    





const styles = StyleSheet.create({
  backgroundContainer: {
    flex: 1,
    width: null,
    height: null,
    justifyContent: 'center',
    alignItems: 'center',
  },
  
  logoContainer:{
    width:"85%",
    marginLeft:"8%",
    
    marginTop:'18%',
    alignItems: 'center'
  },
  logo: {
width: 225,
height: 225,
alignItems:"center",

resizeMode: 'contain',
  },
  logoText: {
    
    marginTop:"50%",
    color: '#ded776',
    fontSize: 15,
    fontWeight: '200',
    fontFamily:'Yananeska Personal Use',
    opacity: 0.5
  },
  linearGradient:{
   flex:1,
     height: 35,
    paddingLeft: 80,
    paddingRight: 80,
    borderRadius: 50,
    marginBottom:3,
    marginTop: "10%"
     
    },
    buttonText:{
      textAlign:'center',
      marginTop:'5%',
      fontFamily:'Roboto',
      fontSize: 15,
      
    },
    tntxtstyle1:{
      flex:1,
      height:37,
      fontSize:16,
      textAlign:"center",
      paddingTop:5,
      color:'#ded776',
      borderWidth: 2,
      borderColor: '#ded776',
      width:"100%",
      marginTop:"4%",
      borderRadius:50,
     
      
    },
    
    alreadyText:{
    marginTop:'18%',
    color:"white",
      fontSize: 15,
    fontFamily: 'Roboto',
    textAlign:"center",

  },
  whenText:{
    color:"white",
      fontSize: 13,
    fontFamily: 'Roboto',
    marginTop:8,
    textAlign:"center"
  },
  withText:{
    color:"white",
      fontSize: 13,
      marginTop:5,
    fontFamily: 'Roboto',
    textAlign:"center"
  },

 underline:{
   marginTop:30,

   height:2,
   paddingLeft:300,
   backgroundColor:'white',
  

 }
  
});



// dont change
const mapStateToProps = state => ({
  loading: state.auth.loading
});

export default connect(
  mapStateToProps,
  null
)(DemoScreen);